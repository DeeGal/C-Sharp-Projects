﻿namespace Prak_10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DaysStayedLabel = new System.Windows.Forms.Label();
            this.restaurantChargesLabel = new System.Windows.Forms.Label();
            this.treatmentChargesLabel = new System.Windows.Forms.Label();
            this.carRentalChargesLabel = new System.Windows.Forms.Label();
            this.medicationAndRehabilitationBillLabel = new System.Windows.Forms.Label();
            this.daysStayedInputTextBox = new System.Windows.Forms.TextBox();
            this.restaurantChargesInputTextBox = new System.Windows.Forms.TextBox();
            this.treatmentChargesInputTextBox = new System.Windows.Forms.TextBox();
            this.carRentalChargesInputTextBox = new System.Windows.Forms.TextBox();
            this.medicationAndRehabilitationBillInputTextBox = new System.Windows.Forms.TextBox();
            this.calculateTotalChargesButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.outputCalculationsListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // DaysStayedLabel
            // 
            this.DaysStayedLabel.AutoSize = true;
            this.DaysStayedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DaysStayedLabel.Location = new System.Drawing.Point(14, 25);
            this.DaysStayedLabel.Name = "DaysStayedLabel";
            this.DaysStayedLabel.Size = new System.Drawing.Size(145, 20);
            this.DaysStayedLabel.TabIndex = 0;
            this.DaysStayedLabel.Text = "No. of Days Stayed";
            // 
            // restaurantChargesLabel
            // 
            this.restaurantChargesLabel.AutoSize = true;
            this.restaurantChargesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restaurantChargesLabel.Location = new System.Drawing.Point(14, 70);
            this.restaurantChargesLabel.Name = "restaurantChargesLabel";
            this.restaurantChargesLabel.Size = new System.Drawing.Size(254, 20);
            this.restaurantChargesLabel.TabIndex = 1;
            this.restaurantChargesLabel.Text = "Restaurant Charges including VAT";
            // 
            // treatmentChargesLabel
            // 
            this.treatmentChargesLabel.AutoSize = true;
            this.treatmentChargesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treatmentChargesLabel.Location = new System.Drawing.Point(14, 120);
            this.treatmentChargesLabel.Name = "treatmentChargesLabel";
            this.treatmentChargesLabel.Size = new System.Drawing.Size(261, 20);
            this.treatmentChargesLabel.TabIndex = 2;
            this.treatmentChargesLabel.Text = "Spa and Health Treatment Charges";
            // 
            // carRentalChargesLabel
            // 
            this.carRentalChargesLabel.AutoSize = true;
            this.carRentalChargesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carRentalChargesLabel.Location = new System.Drawing.Point(14, 165);
            this.carRentalChargesLabel.Name = "carRentalChargesLabel";
            this.carRentalChargesLabel.Size = new System.Drawing.Size(172, 20);
            this.carRentalChargesLabel.TabIndex = 3;
            this.carRentalChargesLabel.Text = "Charges for Car Rental";
            // 
            // medicationAndRehabilitationBillLabel
            // 
            this.medicationAndRehabilitationBillLabel.AutoSize = true;
            this.medicationAndRehabilitationBillLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medicationAndRehabilitationBillLabel.Location = new System.Drawing.Point(14, 219);
            this.medicationAndRehabilitationBillLabel.Name = "medicationAndRehabilitationBillLabel";
            this.medicationAndRehabilitationBillLabel.Size = new System.Drawing.Size(242, 20);
            this.medicationAndRehabilitationBillLabel.TabIndex = 4;
            this.medicationAndRehabilitationBillLabel.Text = "Medication and Rehabilitation Bill";
            // 
            // daysStayedInputTextBox
            // 
            this.daysStayedInputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daysStayedInputTextBox.Location = new System.Drawing.Point(321, 25);
            this.daysStayedInputTextBox.Name = "daysStayedInputTextBox";
            this.daysStayedInputTextBox.Size = new System.Drawing.Size(151, 26);
            this.daysStayedInputTextBox.TabIndex = 5;
            // 
            // restaurantChargesInputTextBox
            // 
            this.restaurantChargesInputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restaurantChargesInputTextBox.Location = new System.Drawing.Point(321, 70);
            this.restaurantChargesInputTextBox.Name = "restaurantChargesInputTextBox";
            this.restaurantChargesInputTextBox.Size = new System.Drawing.Size(151, 26);
            this.restaurantChargesInputTextBox.TabIndex = 6;
            // 
            // treatmentChargesInputTextBox
            // 
            this.treatmentChargesInputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.treatmentChargesInputTextBox.Location = new System.Drawing.Point(321, 120);
            this.treatmentChargesInputTextBox.Name = "treatmentChargesInputTextBox";
            this.treatmentChargesInputTextBox.Size = new System.Drawing.Size(151, 26);
            this.treatmentChargesInputTextBox.TabIndex = 7;
            // 
            // carRentalChargesInputTextBox
            // 
            this.carRentalChargesInputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carRentalChargesInputTextBox.Location = new System.Drawing.Point(321, 165);
            this.carRentalChargesInputTextBox.Name = "carRentalChargesInputTextBox";
            this.carRentalChargesInputTextBox.Size = new System.Drawing.Size(151, 26);
            this.carRentalChargesInputTextBox.TabIndex = 8;
            // 
            // medicationAndRehabilitationBillInputTextBox
            // 
            this.medicationAndRehabilitationBillInputTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.medicationAndRehabilitationBillInputTextBox.Location = new System.Drawing.Point(321, 216);
            this.medicationAndRehabilitationBillInputTextBox.Name = "medicationAndRehabilitationBillInputTextBox";
            this.medicationAndRehabilitationBillInputTextBox.Size = new System.Drawing.Size(151, 26);
            this.medicationAndRehabilitationBillInputTextBox.TabIndex = 9;
            // 
            // calculateTotalChargesButton
            // 
            this.calculateTotalChargesButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateTotalChargesButton.Location = new System.Drawing.Point(18, 274);
            this.calculateTotalChargesButton.Name = "calculateTotalChargesButton";
            this.calculateTotalChargesButton.Size = new System.Drawing.Size(238, 55);
            this.calculateTotalChargesButton.TabIndex = 10;
            this.calculateTotalChargesButton.Text = "Calculate Total Charges";
            this.calculateTotalChargesButton.UseVisualStyleBackColor = true;
            this.calculateTotalChargesButton.Click += new System.EventHandler(this.calculateTotalChargesButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(329, 274);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(143, 55);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // outputCalculationsListBox
            // 
            this.outputCalculationsListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputCalculationsListBox.FormattingEnabled = true;
            this.outputCalculationsListBox.ItemHeight = 20;
            this.outputCalculationsListBox.Location = new System.Drawing.Point(12, 372);
            this.outputCalculationsListBox.Name = "outputCalculationsListBox";
            this.outputCalculationsListBox.Size = new System.Drawing.Size(476, 184);
            this.outputCalculationsListBox.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 560);
            this.Controls.Add(this.outputCalculationsListBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateTotalChargesButton);
            this.Controls.Add(this.medicationAndRehabilitationBillInputTextBox);
            this.Controls.Add(this.carRentalChargesInputTextBox);
            this.Controls.Add(this.treatmentChargesInputTextBox);
            this.Controls.Add(this.restaurantChargesInputTextBox);
            this.Controls.Add(this.daysStayedInputTextBox);
            this.Controls.Add(this.medicationAndRehabilitationBillLabel);
            this.Controls.Add(this.carRentalChargesLabel);
            this.Controls.Add(this.treatmentChargesLabel);
            this.Controls.Add(this.restaurantChargesLabel);
            this.Controls.Add(this.DaysStayedLabel);
            this.Name = "Form1";
            this.Text = "Resort Charges";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label DaysStayedLabel;
        private System.Windows.Forms.Label restaurantChargesLabel;
        private System.Windows.Forms.Label treatmentChargesLabel;
        private System.Windows.Forms.Label carRentalChargesLabel;
        private System.Windows.Forms.Label medicationAndRehabilitationBillLabel;
        private System.Windows.Forms.TextBox daysStayedInputTextBox;
        private System.Windows.Forms.TextBox restaurantChargesInputTextBox;
        private System.Windows.Forms.TextBox treatmentChargesInputTextBox;
        private System.Windows.Forms.TextBox carRentalChargesInputTextBox;
        private System.Windows.Forms.TextBox medicationAndRehabilitationBillInputTextBox;
        private System.Windows.Forms.Button calculateTotalChargesButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ListBox outputCalculationsListBox;
    }
}

