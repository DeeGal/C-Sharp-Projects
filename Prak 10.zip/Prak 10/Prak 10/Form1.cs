﻿//Diana, Mudau - 32582668

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prak_10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //The CalcStayCharges method accepts the two arguments
        //and returns the multiplication of the arguments.
        private double CalcStayCharges (int daysNumber,int num)
        {
            num = 550;
           double stayCharge = daysNumber * num;
           return stayCharge; 
        }
        //The CalMiscCharges method accepts the four double arguments
        //and returns the addition of the arguments.
        private double CalMiscCharges(double foodBill, double spaCharges, double carRental, double medAndRehabilCharges)
        {
            double sumCharges = foodBill + spaCharges + carRental + medAndRehabilCharges;
            return sumCharges; 
        }
        //The CalcTotalCharges method accepts the two double CalcStayCharges and CalMiscCharges arguments
        //and returns the addition of the arguments.
        private double CalcTotalCharges (double stayCharge, double sumCharges)
        {
            double chargesTotal = stayCharge + sumCharges;
            return chargesTotal; 
        }

        private void calculateTotalChargesButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Variables
                int daysNumber;
                double foodBill;
                double spaCharges;
                double carRental;
                double medAndRehabilCharges;
                double chargesTotal;
                double sumCharges;
                double stayCharge;
                int num = 550;

                //Get the No. of days stayed.
                if (int.TryParse(daysStayedInputTextBox.Text, out daysNumber))
                {
                    outputCalculationsListBox.Items.Clear();
                    //Get the muliplication of the stayCharges.
                    stayCharge = CalcStayCharges(daysNumber, num);
                    //Display the stay charges inside the listbox.
                    outputCalculationsListBox.Items.Add("Stay Charges : " + stayCharge.ToString("C"));  
                    //Get the Restaurant charges. 
                    if (double.TryParse (restaurantChargesInputTextBox.Text,out foodBill))
                    {
                        //Get the Spa and treatment charges.
                        if (double.TryParse (treatmentChargesInputTextBox.Text,out spaCharges))
                        {
                            //Get the Car rental charges.
                            if (double.TryParse(carRentalChargesInputTextBox.Text, out carRental))
                            {
                                //Get the Medication and Rehabilitation Bill.
                                if(double .TryParse (medicationAndRehabilitationBillInputTextBox.Text, out medAndRehabilCharges))
                                {
                                    //Get the addition of the Miscellaneous charges.
                                    sumCharges = CalMiscCharges(foodBill, spaCharges, carRental, medAndRehabilCharges);
                                    //Display the Miscellaneous charges inside the listbox.
                                    outputCalculationsListBox.Items.Add("Miscellaneous Charges : " + sumCharges.ToString("C"));

                                    //Get the Total Bill calculations.
                                    chargesTotal = CalcTotalCharges(stayCharge, sumCharges);
                                    //Display the Total bill inside the listbox.
                                    outputCalculationsListBox.Items.Add("Total Bill : " + chargesTotal.ToString("C"));

                                }
                                else
                                {
                                    //Display an error message.
                                    MessageBox.Show("Invalid Medication And Rehabilitation Bill entered."); 
                                }
                            }
                            else
                            {
                                //Display an error message.
                                MessageBox.Show("Invalid Car Rental Charges entered.");
                            }
                        }
                        else
                        {
                            //Display an error message.
                            MessageBox.Show("Invalid Treatment Charges entered.");
                        }
                    }
                    else
                    {
                        //Display an error message.
                        MessageBox.Show("Invalid Restaurant Charges entered.");
                    }
                }
                else
                {
                    //Display an error message.
                    MessageBox.Show("Invalid No. of Days stayed entered.");
                }
            }
            catch (Exception ex)
            {
                //Display an error message.
                MessageBox.Show(ex.Message); 
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
