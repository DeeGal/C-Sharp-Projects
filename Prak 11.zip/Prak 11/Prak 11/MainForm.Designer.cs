﻿namespace Prak_11
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displayButton = new System.Windows.Forms.Button();
            this.mealPlanLabel = new System.Windows.Forms.Label();
            this.dormitoryLabel = new System.Windows.Forms.Label();
            this.dormitorySelectionListBox = new System.Windows.Forms.ListBox();
            this.mealPlanSelectionListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // displayButton
            // 
            this.displayButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayButton.Location = new System.Drawing.Point(216, 276);
            this.displayButton.Name = "displayButton";
            this.displayButton.Size = new System.Drawing.Size(163, 47);
            this.displayButton.TabIndex = 0;
            this.displayButton.Text = "&Display";
            this.displayButton.UseVisualStyleBackColor = true;
            this.displayButton.Click += new System.EventHandler(this.displayButton_Click);
            // 
            // mealPlanLabel
            // 
            this.mealPlanLabel.AutoSize = true;
            this.mealPlanLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealPlanLabel.Location = new System.Drawing.Point(308, 23);
            this.mealPlanLabel.Name = "mealPlanLabel";
            this.mealPlanLabel.Size = new System.Drawing.Size(94, 22);
            this.mealPlanLabel.TabIndex = 1;
            this.mealPlanLabel.Text = "Meal Plan:";
            // 
            // dormitoryLabel
            // 
            this.dormitoryLabel.AutoSize = true;
            this.dormitoryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dormitoryLabel.Location = new System.Drawing.Point(25, 23);
            this.dormitoryLabel.Name = "dormitoryLabel";
            this.dormitoryLabel.Size = new System.Drawing.Size(92, 22);
            this.dormitoryLabel.TabIndex = 2;
            this.dormitoryLabel.Text = "Dormitory:";
            // 
            // dormitorySelectionListBox
            // 
            this.dormitorySelectionListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dormitorySelectionListBox.FormattingEnabled = true;
            this.dormitorySelectionListBox.ItemHeight = 24;
            this.dormitorySelectionListBox.Items.AddRange(new object[] {
            "Allen Hall",
            "Pike Hall",
            "Farthing Hall",
            "University Suites"});
            this.dormitorySelectionListBox.Location = new System.Drawing.Point(29, 67);
            this.dormitorySelectionListBox.Name = "dormitorySelectionListBox";
            this.dormitorySelectionListBox.Size = new System.Drawing.Size(255, 172);
            this.dormitorySelectionListBox.TabIndex = 3;
            this.dormitorySelectionListBox.SelectedIndexChanged += new System.EventHandler(this.dormitorySelectionListBox_SelectedIndexChanged);
            // 
            // mealPlanSelectionListBox
            // 
            this.mealPlanSelectionListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealPlanSelectionListBox.FormattingEnabled = true;
            this.mealPlanSelectionListBox.ItemHeight = 24;
            this.mealPlanSelectionListBox.Items.AddRange(new object[] {
            "7 meals per week",
            "14 meals per week",
            "Unlimited meals"});
            this.mealPlanSelectionListBox.Location = new System.Drawing.Point(312, 67);
            this.mealPlanSelectionListBox.Name = "mealPlanSelectionListBox";
            this.mealPlanSelectionListBox.Size = new System.Drawing.Size(265, 172);
            this.mealPlanSelectionListBox.TabIndex = 4;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 375);
            this.Controls.Add(this.mealPlanSelectionListBox);
            this.Controls.Add(this.dormitorySelectionListBox);
            this.Controls.Add(this.dormitoryLabel);
            this.Controls.Add(this.mealPlanLabel);
            this.Controls.Add(this.displayButton);
            this.Name = "MainForm";
            this.Text = "Program9_6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button displayButton;
        private System.Windows.Forms.Label mealPlanLabel;
        private System.Windows.Forms.Label dormitoryLabel;
        private System.Windows.Forms.ListBox dormitorySelectionListBox;
        private System.Windows.Forms.ListBox mealPlanSelectionListBox;
    }
}

