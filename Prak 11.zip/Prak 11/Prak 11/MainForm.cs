﻿//Diana,Mudau - 32582668

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prak_11
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            //Variables
            string selectedDormitory;
            string mealPlan;
            string total2;
            string total3;
            string total4;

            //Create an instance of the dispayForm class.
            MyForm2 displayForm = new MyForm2();

            if (dormitorySelectionListBox.SelectedIndex != -1)
            {

                selectedDormitory = dormitorySelectionListBox.SelectedItem.ToString();


                switch (selectedDormitory)
                {
                    case "Allen Hall":
                        displayForm.dormitoryOutputLabel.Text = 1500.ToString("c") + "  " + "per semester";
                        break;
                    case "Pike Hall":
                        displayForm.dormitoryOutputLabel.Text = 1600.ToString("c") + "  " + "per semester";
                        break;
                    case "Farthing Hall":
                        displayForm.dormitoryOutputLabel.Text = 1800.ToString("c") + "  " + "per semester";
                        break;
                    case "University Suites":
                        displayForm.dormitoryOutputLabel.Text = 2500.ToString("c") + "  " + "per semester";
                        break;
                }
            }
            if (mealPlanSelectionListBox.SelectedIndex != -1)
            {
                mealPlan = mealPlanSelectionListBox.SelectedItem.ToString();

                switch (mealPlan)
                {
                    case "7 meals per week":
                        displayForm.mealPlanOutputLabel.Text = 600.ToString("c") + "  " + "per semester";
                        break;
                    case "14 meals per week":
                        displayForm.mealPlanOutputLabel.Text = 1200.ToString("c") + "  " + "per semester ";
                        break;
                    case "Unlimited meals":
                        displayForm.mealPlanOutputLabel.Text = 1700.ToString("c") + "  " + "per semester ";
                        break;
                }
            }
            else
            {
                MessageBox.Show("Select a Meal Plan to proceed.");
            }
            if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
            {
                total2 = mealPlanSelectionListBox.SelectedItem.ToString();
                total2 = dormitorySelectionListBox.SelectedItem.ToString();

                switch (total2)
                {
                    case "Allen Hall":
                    case "14 meals per week":
                        displayForm.totalOutputLabel.Text = 2700.ToString("c") + "  ";
                        break;
                }
            }
                if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                {
                    total2 = mealPlanSelectionListBox.SelectedItem.ToString();
                    total2 = dormitorySelectionListBox.SelectedItem.ToString();

                    switch (total2)
                    {
                        case "Pike Hall":
                        case "14 meals per week":
                            displayForm.totalOutputLabel.Text = 2800.ToString("c") + "  ";
                            break;
                    }
                }
                if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                {
                    total2 = mealPlanSelectionListBox.SelectedItem.ToString();
                    total2 = dormitorySelectionListBox.SelectedItem.ToString();

                    switch (total2)
                    {
                        case "Farthing Hall":
                        case "14 meals per week":
                            displayForm.totalOutputLabel.Text = 3000.ToString("c") + "  ";
                            break;
                    }

                    if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                    {
                        total2 = mealPlanSelectionListBox.SelectedItem.ToString();
                        total2 = dormitorySelectionListBox.SelectedItem.ToString();

                        switch (total2)
                        {
                            case "University Suites":
                            case "14 meals per week":
                                displayForm.totalOutputLabel.Text = 3700.ToString("c") + "  ";
                                break;
                        }
                    }

                   else if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                    {

                        total3 = mealPlanSelectionListBox.SelectedItem.ToString();
                        total3 = dormitorySelectionListBox.SelectedItem.ToString();

                        switch (total3)
                        {
                            case "Allen Hall":
                            case "Unlimited meals":
                                displayForm.totalOutputLabel.Text = 3200.ToString("c") + "  ";
                                break;
                        }

                    }
                    if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                    {
                        total3 = mealPlanSelectionListBox.SelectedItem.ToString();
                        total3 = dormitorySelectionListBox.SelectedItem.ToString();

                        switch (total3)
                        {
                            case "Pike Hall":
                            case "Unlimited meals":
                                displayForm.totalOutputLabel.Text = 3300.ToString("c") + "  ";
                                break;
                        }

                    }
                    if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                    {
                        total3 = mealPlanSelectionListBox.SelectedItem.ToString();
                        total3 = dormitorySelectionListBox.SelectedItem.ToString();

                        switch (total3)
                        {
                            case "Farthing Hall":
                            case "Unlimited meals":
                                displayForm.totalOutputLabel.Text = 3500.ToString("c") + "  ";
                                break;
                        }
                    }
                    if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                    {
                        total3 = mealPlanSelectionListBox.SelectedItem.ToString();
                        total3 = dormitorySelectionListBox.SelectedItem.ToString();

                        switch (total3)
                        {
                            case "University Suites":
                            case "Unlimited meals":
                                displayForm.totalOutputLabel.Text = 4200.ToString("c") + "  ";
                                break;

                        }
                    }
                     else if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                     {
                         total4 = mealPlanSelectionListBox.SelectedItem.ToString();
                          total4 = dormitorySelectionListBox.SelectedItem.ToString();

                          switch (total4)
                          {
                            case "Allen Hall":
                            case "7 meals per week":
                            displayForm.totalOutputLabel.Text = 2100.ToString("c") + "  ";
                            break;
                    }
                }
                if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                {
                    total4 = mealPlanSelectionListBox.SelectedItem.ToString();
                    total4 = dormitorySelectionListBox.SelectedItem.ToString();

                    switch (total4)
                    {
                        case "Pike Hall":
                        case "7 meals per week":
                            displayForm.totalOutputLabel.Text = 2200.ToString("c") + "  ";
                            break;
                    }
                }
                if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                {
                    total4 = mealPlanSelectionListBox.SelectedItem.ToString();
                    total4 = dormitorySelectionListBox.SelectedItem.ToString();
                    switch (total4)
                    {
                        case "Farthing Hall":
                        case "7 meals per week":
                            displayForm.totalOutputLabel.Text = 2400.ToString("c") + "  ";
                            break;
                    }
                }
                if (dormitorySelectionListBox.SelectedIndex != -1 && mealPlanSelectionListBox.SelectedIndex != -1)
                {
                    total4 = mealPlanSelectionListBox.SelectedItem.ToString();
                    total4 = dormitorySelectionListBox.SelectedItem.ToString();
                    switch (total4)
                    {
                        case "University Suites":
                        case "7 meals per week":
                            displayForm.totalOutputLabel.Text = 3100.ToString("c") + "  ";
                            break;
                    }
                }
            }
            else
            {
                MessageBox.Show("Select the Dormitory and the Meal Plan in order to calulate the total costs.");
            }
                //Display  the form.
                displayForm.ShowDialog();
        }
        public void mealPlanSelectionListBoxes_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
        private void dormitorySelectionListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}


