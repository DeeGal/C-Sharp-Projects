﻿namespace Prak_11
{
    partial class MyForm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormitoryLabel = new System.Windows.Forms.Label();
            this.mealPlanLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.dormitoryOutputLabel = new System.Windows.Forms.Label();
            this.mealPlanOutputLabel = new System.Windows.Forms.Label();
            this.totalOutputLabel = new System.Windows.Forms.Label();
            this.closeButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // dormitoryLabel
            // 
            this.dormitoryLabel.AutoSize = true;
            this.dormitoryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dormitoryLabel.Location = new System.Drawing.Point(35, 35);
            this.dormitoryLabel.Name = "dormitoryLabel";
            this.dormitoryLabel.Size = new System.Drawing.Size(95, 24);
            this.dormitoryLabel.TabIndex = 1;
            this.dormitoryLabel.Text = "Dormitory:";
            // 
            // mealPlanLabel
            // 
            this.mealPlanLabel.AutoSize = true;
            this.mealPlanLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealPlanLabel.Location = new System.Drawing.Point(35, 93);
            this.mealPlanLabel.Name = "mealPlanLabel";
            this.mealPlanLabel.Size = new System.Drawing.Size(98, 24);
            this.mealPlanLabel.TabIndex = 2;
            this.mealPlanLabel.Text = "Meal Plan:";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(35, 156);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(56, 24);
            this.totalLabel.TabIndex = 3;
            this.totalLabel.Text = "Total:";
            // 
            // dormitoryOutputLabel
            // 
            this.dormitoryOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dormitoryOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dormitoryOutputLabel.Location = new System.Drawing.Point(203, 35);
            this.dormitoryOutputLabel.Name = "dormitoryOutputLabel";
            this.dormitoryOutputLabel.Size = new System.Drawing.Size(272, 38);
            this.dormitoryOutputLabel.TabIndex = 4;
            // 
            // mealPlanOutputLabel
            // 
            this.mealPlanOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mealPlanOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mealPlanOutputLabel.Location = new System.Drawing.Point(203, 93);
            this.mealPlanOutputLabel.Name = "mealPlanOutputLabel";
            this.mealPlanOutputLabel.Size = new System.Drawing.Size(272, 38);
            this.mealPlanOutputLabel.TabIndex = 5;
            // 
            // totalOutputLabel
            // 
            this.totalOutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalOutputLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalOutputLabel.Location = new System.Drawing.Point(203, 156);
            this.totalOutputLabel.Name = "totalOutputLabel";
            this.totalOutputLabel.Size = new System.Drawing.Size(272, 38);
            this.totalOutputLabel.TabIndex = 6;
            // 
            // closeButton
            // 
            this.closeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeButton.Location = new System.Drawing.Point(295, 219);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(126, 34);
            this.closeButton.TabIndex = 7;
            this.closeButton.Text = "&Close";
            this.closeButton.UseVisualStyleBackColor = true;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // MyForm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 265);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.totalOutputLabel);
            this.Controls.Add(this.mealPlanOutputLabel);
            this.Controls.Add(this.dormitoryOutputLabel);
            this.Controls.Add(this.totalLabel);
            this.Controls.Add(this.mealPlanLabel);
            this.Controls.Add(this.dormitoryLabel);
            this.Name = "MyForm2";
            this.Text = "MyForm2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label dormitoryLabel;
        public System.Windows.Forms.Label mealPlanLabel;
        public System.Windows.Forms.Label totalLabel;
        public System.Windows.Forms.Label dormitoryOutputLabel;
        public System.Windows.Forms.Label mealPlanOutputLabel;
        public System.Windows.Forms.Label totalOutputLabel;
        public System.Windows.Forms.Button closeButton;
    }
}