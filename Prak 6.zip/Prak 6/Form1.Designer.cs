﻿namespace Prak_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.showPayButton = new System.Windows.Forms.Button();
            this.inputCompensationTextBox = new System.Windows.Forms.TextBox();
            this.initialCompensationAmountLabel = new System.Windows.Forms.Label();
            this.outputCompensationListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(409, 262);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 59);
            this.exitButton.TabIndex = 0;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // showPayButton
            // 
            this.showPayButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showPayButton.Location = new System.Drawing.Point(409, 100);
            this.showPayButton.Name = "showPayButton";
            this.showPayButton.Size = new System.Drawing.Size(112, 59);
            this.showPayButton.TabIndex = 1;
            this.showPayButton.Text = "Show Pay";
            this.showPayButton.UseVisualStyleBackColor = true;
            this.showPayButton.Click += new System.EventHandler(this.showPayButton_Click);
            // 
            // inputCompensationTextBox
            // 
            this.inputCompensationTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputCompensationTextBox.Location = new System.Drawing.Point(309, 39);
            this.inputCompensationTextBox.Name = "inputCompensationTextBox";
            this.inputCompensationTextBox.Size = new System.Drawing.Size(212, 26);
            this.inputCompensationTextBox.TabIndex = 2;
            // 
            // initialCompensationAmountLabel
            // 
            this.initialCompensationAmountLabel.AutoSize = true;
            this.initialCompensationAmountLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.initialCompensationAmountLabel.Location = new System.Drawing.Point(9, 39);
            this.initialCompensationAmountLabel.Name = "initialCompensationAmountLabel";
            this.initialCompensationAmountLabel.Size = new System.Drawing.Size(271, 18);
            this.initialCompensationAmountLabel.TabIndex = 3;
            this.initialCompensationAmountLabel.Text = "Enter a teacher\'s initial compensation:";
            // 
            // outputCompensationListBox
            // 
            this.outputCompensationListBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.outputCompensationListBox.FormattingEnabled = true;
            this.outputCompensationListBox.ItemHeight = 18;
            this.outputCompensationListBox.Items.AddRange(new object[] {
            "Year     Pay"});
            this.outputCompensationListBox.Location = new System.Drawing.Point(12, 100);
            this.outputCompensationListBox.Name = "outputCompensationListBox";
            this.outputCompensationListBox.Size = new System.Drawing.Size(274, 220);
            this.outputCompensationListBox.TabIndex = 4;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 355);
            this.Controls.Add(this.outputCompensationListBox);
            this.Controls.Add(this.initialCompensationAmountLabel);
            this.Controls.Add(this.inputCompensationTextBox);
            this.Controls.Add(this.showPayButton);
            this.Controls.Add(this.exitButton);
            this.Name = "Form1";
            this.Text = "Teachers\' Pay Increase";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button showPayButton;
        private System.Windows.Forms.TextBox inputCompensationTextBox;
        private System.Windows.Forms.Label initialCompensationAmountLabel;
        private System.Windows.Forms.ListBox outputCompensationListBox;
    }
}

