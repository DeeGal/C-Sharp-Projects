﻿//Diana,Mudau -32582668

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prak_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showPayButton_Click(object sender, EventArgs e)
        {
            //Constant for the yealy percentage increase.
            const decimal PERCENTAGE_INCREASE = 0.05m;

            //Local variables
            decimal compensation;//The initial compensation amount.
            int count = 1;//Loop counter, initialized with 1.

            //Get the initial compensation amount.
            if (decimal.TryParse(inputCompensationTextBox.Text, out compensation))
            {
                //Display this year's compensation amount.
                outputCompensationListBox.Items.Add(count + "  " + "         " + compensation.ToString("c"));
                //Add one year to the loop counter.
                count = count + 1;
            }
            //Get the initial compensation amount.
            if (decimal.TryParse(inputCompensationTextBox.Text, out compensation))
            {
                //The following loop calculates the projected teachers' pay amount for the next five years.
                while (count <= 5)
                {
                    //Add the initial amounts with the percentage increase after the 1st year's amount. 
                    compensation = compensation + (PERCENTAGE_INCREASE * compensation);
                    //Diplay the compensation amounts.
                    outputCompensationListBox.Items.Add(count + "  " + "         " + compensation.ToString("c"));
                    //Add one year to the loop counter.
                    count = count + 1;
                }
            }
            else
            {
                //Invalid initial compensation amount was entered.
                MessageBox.Show("Invalid Compensation Amount Entered.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
