﻿namespace Prak_7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.showCaloriesBurntButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.weightLabel = new System.Windows.Forms.Label();
            this.weightInputTextBox = new System.Windows.Forms.TextBox();
            this.weightOutputListBox = new System.Windows.Forms.ListBox();
            this.exerciseGroupBox = new System.Windows.Forms.GroupBox();
            this.cyclingRadioButton = new System.Windows.Forms.RadioButton();
            this.runningRadioButton = new System.Windows.Forms.RadioButton();
            this.rowingRadioButton = new System.Windows.Forms.RadioButton();
            this.kgLabel = new System.Windows.Forms.Label();
            this.exerciseGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // showCaloriesBurntButton
            // 
            this.showCaloriesBurntButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showCaloriesBurntButton.Location = new System.Drawing.Point(428, 293);
            this.showCaloriesBurntButton.Name = "showCaloriesBurntButton";
            this.showCaloriesBurntButton.Size = new System.Drawing.Size(218, 56);
            this.showCaloriesBurntButton.TabIndex = 0;
            this.showCaloriesBurntButton.Text = "Show Calories Burnt";
            this.showCaloriesBurntButton.UseVisualStyleBackColor = true;
            this.showCaloriesBurntButton.Click += new System.EventHandler(this.showCaloriesBurntButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(428, 381);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(218, 56);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // weightLabel
            // 
            this.weightLabel.AutoSize = true;
            this.weightLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weightLabel.Location = new System.Drawing.Point(9, 43);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(61, 18);
            this.weightLabel.TabIndex = 2;
            this.weightLabel.Text = "Weight:";
            // 
            // weightInputTextBox
            // 
            this.weightInputTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weightInputTextBox.Location = new System.Drawing.Point(132, 43);
            this.weightInputTextBox.Name = "weightInputTextBox";
            this.weightInputTextBox.Size = new System.Drawing.Size(225, 26);
            this.weightInputTextBox.TabIndex = 3;
            // 
            // weightOutputListBox
            // 
            this.weightOutputListBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weightOutputListBox.FormattingEnabled = true;
            this.weightOutputListBox.ItemHeight = 18;
            this.weightOutputListBox.Items.AddRange(new object[] {
            "Minutes   Calories Burnt"});
            this.weightOutputListBox.Location = new System.Drawing.Point(12, 91);
            this.weightOutputListBox.Name = "weightOutputListBox";
            this.weightOutputListBox.Size = new System.Drawing.Size(345, 346);
            this.weightOutputListBox.TabIndex = 4;
            // 
            // exerciseGroupBox
            // 
            this.exerciseGroupBox.Controls.Add(this.rowingRadioButton);
            this.exerciseGroupBox.Controls.Add(this.runningRadioButton);
            this.exerciseGroupBox.Controls.Add(this.cyclingRadioButton);
            this.exerciseGroupBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exerciseGroupBox.Location = new System.Drawing.Point(420, 91);
            this.exerciseGroupBox.Name = "exerciseGroupBox";
            this.exerciseGroupBox.Size = new System.Drawing.Size(226, 165);
            this.exerciseGroupBox.TabIndex = 5;
            this.exerciseGroupBox.TabStop = false;
            this.exerciseGroupBox.Text = "Exercise";
            // 
            // cyclingRadioButton
            // 
            this.cyclingRadioButton.AutoSize = true;
            this.cyclingRadioButton.Location = new System.Drawing.Point(8, 25);
            this.cyclingRadioButton.Name = "cyclingRadioButton";
            this.cyclingRadioButton.Size = new System.Drawing.Size(77, 22);
            this.cyclingRadioButton.TabIndex = 0;
            this.cyclingRadioButton.TabStop = true;
            this.cyclingRadioButton.Text = "Cycling";
            this.cyclingRadioButton.UseVisualStyleBackColor = true;
            // 
            // runningRadioButton
            // 
            this.runningRadioButton.AutoSize = true;
            this.runningRadioButton.Location = new System.Drawing.Point(8, 68);
            this.runningRadioButton.Name = "runningRadioButton";
            this.runningRadioButton.Size = new System.Drawing.Size(82, 22);
            this.runningRadioButton.TabIndex = 6;
            this.runningRadioButton.TabStop = true;
            this.runningRadioButton.Text = "Running";
            this.runningRadioButton.UseVisualStyleBackColor = true;
            // 
            // rowingRadioButton
            // 
            this.rowingRadioButton.AutoSize = true;
            this.rowingRadioButton.Location = new System.Drawing.Point(8, 115);
            this.rowingRadioButton.Name = "rowingRadioButton";
            this.rowingRadioButton.Size = new System.Drawing.Size(78, 22);
            this.rowingRadioButton.TabIndex = 7;
            this.rowingRadioButton.TabStop = true;
            this.rowingRadioButton.Text = "Rowing";
            this.rowingRadioButton.UseVisualStyleBackColor = true;
            // 
            // kgLabel
            // 
            this.kgLabel.AutoSize = true;
            this.kgLabel.Font = new System.Drawing.Font("Arial", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.kgLabel.Location = new System.Drawing.Point(363, 50);
            this.kgLabel.Name = "kgLabel";
            this.kgLabel.Size = new System.Drawing.Size(23, 16);
            this.kgLabel.TabIndex = 6;
            this.kgLabel.Text = "kg";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 488);
            this.Controls.Add(this.kgLabel);
            this.Controls.Add(this.exerciseGroupBox);
            this.Controls.Add(this.weightOutputListBox);
            this.Controls.Add(this.weightInputTextBox);
            this.Controls.Add(this.weightLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.showCaloriesBurntButton);
            this.Name = "Form1";
            this.Text = "Calories Burned through exercise";
            this.exerciseGroupBox.ResumeLayout(false);
            this.exerciseGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button showCaloriesBurntButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label weightLabel;
        private System.Windows.Forms.TextBox weightInputTextBox;
        private System.Windows.Forms.ListBox weightOutputListBox;
        private System.Windows.Forms.GroupBox exerciseGroupBox;
        private System.Windows.Forms.RadioButton rowingRadioButton;
        private System.Windows.Forms.RadioButton runningRadioButton;
        private System.Windows.Forms.RadioButton cyclingRadioButton;
        private System.Windows.Forms.Label kgLabel;
    }
}

