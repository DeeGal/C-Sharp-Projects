﻿//Diana,Mudau-32582668

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prak_7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showCaloriesBurntButton_Click(object sender, EventArgs e)
        {
            //Local Variables
            double weight;//Body weight.
            int count = 1;//Loop counter, initialized with 1.

            //Get the weight value.
            if (double.TryParse(weightInputTextBox.Text, out weight))
            {
                //When the cycling radio button is checked.
                if (cyclingRadioButton.Checked)
                {
                    while (count <= 5)
                    {
                       //weight = weight + (weight*1.0);
                       weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                       weightOutputListBox.Items.Add("10" + "           " + (weight*1.0).ToString());
                       count++;

                       //weight = weight + (weight*2.0);
                       weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("20" + "           " + (weight*2.0).ToString());
                        count++;

                       //weight = weight + (weight*3.0);
                       weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("30" + "            " + (weight*3.0).ToString());
                        count++;

                       //weight = weight + (weight*4.0);
                       weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("40" + "            " + (weight*4.0).ToString());
                        count++;

                     // weight = weight + (weight*5.0);
                      weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("50" + "            " + (weight*5.0).ToString());
                        count = count + 1;
                    }
                }
                else if (runningRadioButton.Checked)
                    {
                       while (count<5)
                       {
                        //weight = weight + (1.2 * weight);
                        weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("10" + "             " + (weight * 1.2).ToString());
                        count++;
                        // weight = weight + (2.4 * weight);
                        weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("20" + "             " + (weight * 2.4).ToString());
                        count++;
                        // weight = weight + (3.6 * weight);
                        weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("30" + "             " + (weight * 3.6).ToString());
                        count++;
                        // weight = weight + (4.8 * weight);
                        weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("40" + "              " + (weight * 4.8).ToString());
                        count++;
                        // weight = weight + (6 * weight);
                        weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                        weightOutputListBox.Items.Add("50" + "              " + (weight * 6).ToString());
                        count = count + 1;
                       }
                    }
 
                else if (rowingRadioButton.Checked)
                {
                    // weight = weight + (1.2 * weight);
                    weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                    weightOutputListBox.Items.Add("10" + "              " + (weight*1.5).ToString());
                    count++;
                    // weight = weight + (2.4 * weight);
                    weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                    weightOutputListBox.Items.Add("20" + "              " + (weight*3).ToString());
                    count++;
                    // weight = weight + (3.6 * weight);
                    weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                    weightOutputListBox.Items.Add("30" + "              " + (weight*4.5).ToString());
                    count++;
                    // weight = weight + (4.8 * weight);
                    weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                    weightOutputListBox.Items.Add("40" + "              " + (weight*6).ToString());
                    count++;
                    // weight = weight + (6 * weight);
                    weight = Math.Round(weight, 1);//Round off to 1 decimal place.
                    weightOutputListBox.Items.Add("50" + "              " + (weight*7.5).ToString());
                    count = count + 1;
                }
            }
            else
            {
                //Invalid value of weight was entered.
                MessageBox.Show("Invalid weight value entered.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close the form.
            this.Close();
        }
    }
}
