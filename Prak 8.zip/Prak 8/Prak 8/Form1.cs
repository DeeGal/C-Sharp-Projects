﻿//Diana,Mudau - 32582668

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Prak_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Variables
                int number;
                int randnumber;
                int res;
                int sum = 0;
               // int n = 0;
                int count = 1;
                //Declare a StreamWriter variable.
                StreamWriter numbersFile;

                //Get a file and create a StreamWriter object.
                numbersFile = File.CreateText("Numbers.txt");
                //Get the number entered.
                if (int.TryParse(inputNumberTextBox.Text, out number))
                {
                    //Get the random integer in the range 1 to 100. 
                    Random rand = new Random();
                    for (int i = 1; i<=100; i ++)
                    {
                        sum = sum + (rand.Next(1,101));
                        //sum = sum + n;

                    }
                    while (count <= number)
                    {
                        //Write the random numbers to the text file.
                        randnumber = rand.Next(1, 101);
                        numbersFile.WriteLine(randnumber);
                        res = number;
                        numbersFile.WriteLine("The number of value read from file:" + res.ToString());
                        numbersFile.WriteLine("The total of the numbers is:" + sum.ToString());
                        count++;
                    }
                    //Close the file.
                    numbersFile.Close();//CLOSE
                    MessageBox.Show("File saved successfully!");     
                }
                else
                {
                    //Display an error message.
                    MessageBox.Show("Invalid value entered.");  
                }
            }
            catch (IOException ex)
            {
                //Display an error message.
                MessageBox.Show(ex.Message); 
            }
        }

        private void readButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Declare a StreamReader variable.
                StreamReader readFile;

                //open and get a StreamReader object.
                readFile = File.OpenText("Numbers.txt");//OPEN 

                //Read the file's contents.
                while (!readFile.EndOfStream)
                {
                    //Get the file's contents and display in the listbox.
                    outputNumberListBox.Items.Add(readFile.ReadLine());//PROCESS 
                }
                //Close the file. 
                readFile.Close();//CLOSE 
            }
            catch (IOException ex)
            {
                //Display an error message.
                MessageBox.Show(ex.Message);  
            }
        }
    }
}
