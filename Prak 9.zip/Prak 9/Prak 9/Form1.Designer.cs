﻿namespace Prak_9
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.revenueSaleLabel = new System.Windows.Forms.Label();
            this.commissionPercentageLabel = new System.Windows.Forms.Label();
            this.earnedCommissionLabel = new System.Windows.Forms.Label();
            this.earnedCommissonOutputLabel = new System.Windows.Forms.Label();
            this.revenueSaleInputTextBox = new System.Windows.Forms.TextBox();
            this.earnedPercentageTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // revenueSaleLabel
            // 
            this.revenueSaleLabel.AutoSize = true;
            this.revenueSaleLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.revenueSaleLabel.Location = new System.Drawing.Point(23, 24);
            this.revenueSaleLabel.Name = "revenueSaleLabel";
            this.revenueSaleLabel.Size = new System.Drawing.Size(109, 18);
            this.revenueSaleLabel.TabIndex = 0;
            this.revenueSaleLabel.Text = "Revenue Sale:";
            // 
            // commissionPercentageLabel
            // 
            this.commissionPercentageLabel.AutoSize = true;
            this.commissionPercentageLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commissionPercentageLabel.Location = new System.Drawing.Point(22, 98);
            this.commissionPercentageLabel.Name = "commissionPercentageLabel";
            this.commissionPercentageLabel.Size = new System.Drawing.Size(148, 18);
            this.commissionPercentageLabel.TabIndex = 1;
            this.commissionPercentageLabel.Text = "Earned Percentage:";
            // 
            // earnedCommissionLabel
            // 
            this.earnedCommissionLabel.AutoSize = true;
            this.earnedCommissionLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.earnedCommissionLabel.Location = new System.Drawing.Point(22, 182);
            this.earnedCommissionLabel.Name = "earnedCommissionLabel";
            this.earnedCommissionLabel.Size = new System.Drawing.Size(155, 18);
            this.earnedCommissionLabel.TabIndex = 2;
            this.earnedCommissionLabel.Text = "Earned Commission:";
            // 
            // earnedCommissonOutputLabel
            // 
            this.earnedCommissonOutputLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.earnedCommissonOutputLabel.Location = new System.Drawing.Point(183, 173);
            this.earnedCommissonOutputLabel.Name = "earnedCommissonOutputLabel";
            this.earnedCommissonOutputLabel.Size = new System.Drawing.Size(121, 36);
            this.earnedCommissonOutputLabel.TabIndex = 3;
            this.earnedCommissonOutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // revenueSaleInputTextBox
            // 
            this.revenueSaleInputTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.revenueSaleInputTextBox.Location = new System.Drawing.Point(166, 24);
            this.revenueSaleInputTextBox.Name = "revenueSaleInputTextBox";
            this.revenueSaleInputTextBox.Size = new System.Drawing.Size(209, 26);
            this.revenueSaleInputTextBox.TabIndex = 4;
            // 
            // earnedPercentageTextBox
            // 
            this.earnedPercentageTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.earnedPercentageTextBox.Location = new System.Drawing.Point(249, 98);
            this.earnedPercentageTextBox.Name = "earnedPercentageTextBox";
            this.earnedPercentageTextBox.Size = new System.Drawing.Size(126, 26);
            this.earnedPercentageTextBox.TabIndex = 5;
            // 
            // calculateButton
            // 
            this.calculateButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.Location = new System.Drawing.Point(26, 271);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(121, 43);
            this.calculateButton.TabIndex = 6;
            this.calculateButton.Text = "&Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(254, 271);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(121, 43);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "&Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 359);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.earnedPercentageTextBox);
            this.Controls.Add(this.revenueSaleInputTextBox);
            this.Controls.Add(this.earnedCommissonOutputLabel);
            this.Controls.Add(this.earnedCommissionLabel);
            this.Controls.Add(this.commissionPercentageLabel);
            this.Controls.Add(this.revenueSaleLabel);
            this.Name = "Form1";
            this.Text = "Salesperson\'s commission calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label revenueSaleLabel;
        private System.Windows.Forms.Label commissionPercentageLabel;
        private System.Windows.Forms.Label earnedCommissionLabel;
        private System.Windows.Forms.Label earnedCommissonOutputLabel;
        private System.Windows.Forms.TextBox revenueSaleInputTextBox;
        private System.Windows.Forms.TextBox earnedPercentageTextBox;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button exitButton;
    }
}

