﻿//Diana,Mudau - 32582668

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prak_9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }
        // The CalculateDisplayCommission method accepts the two double arguments
        //and returns the multiplication of the arguments.
        private double CalculateDisplayCommission(double revenue,double percentage)
        {   
            double commission = revenue * (percentage/100);
            return commission;  
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //Variables to hold the revenue, percentage and commission.
            double revenue, percentage, commission;

            //Get the sales revenue amount.
            if (double.TryParse(revenueSaleInputTextBox.Text, out revenue))
            {
                //Get the earned percentage amount.
                if (double.TryParse(earnedPercentageTextBox.Text, out percentage))
                {
                    //Calculate the earned commission.
                    commission = CalculateDisplayCommission(revenue, percentage);
                    //Display the earned commission.
                    earnedCommissonOutputLabel.Text = commission.ToString("c");  
                }
                else
                {
                    //Display an error message for the sales revenue amount.
                    MessageBox.Show("Sales revenue amount is invalid."); 
                }
            }
            else
            {
                //Display an error message for the earned percentage amount.
                MessageBox.Show("Earned percentage amount is invalid.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Close the form.
            this.Close();
        }
    }
}
