﻿namespace Project_SU4_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calculateButton = new System.Windows.Forms.Button();
            this.icecreamGroupBox = new System.Windows.Forms.GroupBox();
            this.topppingsCheckBox = new System.Windows.Forms.CheckBox();
            this.inputAmountTextBox = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.amountInputLabel = new System.Windows.Forms.Label();
            this.icecreamOutputListBox = new System.Windows.Forms.ListBox();
            this.icecreamGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // calculateButton
            // 
            this.calculateButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calculateButton.Location = new System.Drawing.Point(6, 317);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(110, 34);
            this.calculateButton.TabIndex = 0;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // icecreamGroupBox
            // 
            this.icecreamGroupBox.Controls.Add(this.topppingsCheckBox);
            this.icecreamGroupBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.icecreamGroupBox.Location = new System.Drawing.Point(6, 56);
            this.icecreamGroupBox.Name = "icecreamGroupBox";
            this.icecreamGroupBox.Size = new System.Drawing.Size(362, 100);
            this.icecreamGroupBox.TabIndex = 1;
            this.icecreamGroupBox.TabStop = false;
            this.icecreamGroupBox.Text = "Ice-cream";
            // 
            // topppingsCheckBox
            // 
            this.topppingsCheckBox.AutoSize = true;
            this.topppingsCheckBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topppingsCheckBox.Location = new System.Drawing.Point(15, 45);
            this.topppingsCheckBox.Name = "topppingsCheckBox";
            this.topppingsCheckBox.Size = new System.Drawing.Size(154, 22);
            this.topppingsCheckBox.TabIndex = 2;
            this.topppingsCheckBox.Text = "Including Toppings";
            this.topppingsCheckBox.UseVisualStyleBackColor = true;
            // 
            // inputAmountTextBox
            // 
            this.inputAmountTextBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inputAmountTextBox.Location = new System.Drawing.Point(127, 12);
            this.inputAmountTextBox.Name = "inputAmountTextBox";
            this.inputAmountTextBox.Size = new System.Drawing.Size(150, 26);
            this.inputAmountTextBox.TabIndex = 5;
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(278, 317);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 34);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // amountInputLabel
            // 
            this.amountInputLabel.AutoSize = true;
            this.amountInputLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amountInputLabel.Location = new System.Drawing.Point(3, 12);
            this.amountInputLabel.Name = "amountInputLabel";
            this.amountInputLabel.Size = new System.Drawing.Size(100, 18);
            this.amountInputLabel.TabIndex = 7;
            this.amountInputLabel.Text = "Input Amount:";
            // 
            // icecreamOutputListBox
            // 
            this.icecreamOutputListBox.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.icecreamOutputListBox.FormattingEnabled = true;
            this.icecreamOutputListBox.ItemHeight = 18;
            this.icecreamOutputListBox.Items.AddRange(new object[] {
            "Ice-Cream                           Amount Left"});
            this.icecreamOutputListBox.Location = new System.Drawing.Point(6, 173);
            this.icecreamOutputListBox.Name = "icecreamOutputListBox";
            this.icecreamOutputListBox.Size = new System.Drawing.Size(362, 94);
            this.icecreamOutputListBox.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(435, 454);
            this.Controls.Add(this.icecreamOutputListBox);
            this.Controls.Add(this.amountInputLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.inputAmountTextBox);
            this.Controls.Add(this.icecreamGroupBox);
            this.Controls.Add(this.calculateButton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.icecreamGroupBox.ResumeLayout(false);
            this.icecreamGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.GroupBox icecreamGroupBox;
        private System.Windows.Forms.CheckBox topppingsCheckBox;
        private System.Windows.Forms.TextBox inputAmountTextBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label amountInputLabel;
        private System.Windows.Forms.ListBox icecreamOutputListBox;
    }
}

