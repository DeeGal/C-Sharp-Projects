﻿//Diana,Mudau -32582668


using System;
using System.Windows.Forms;

namespace Project_SU4_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            //local variables
            decimal amount;
            string sInput = "";
            int count =1;

            //constant variables
            const decimal ICE_CREAM_PRICE = 15.00m;
            const decimal TOPPINGS_PRICE = 3.50M;

            if (decimal.TryParse(inputAmountTextBox.Text, out amount))
            {
                if (topppingsCheckBox.Checked)
                {
                    while (count <= 1)
                    {
                        amount = amount - (ICE_CREAM_PRICE + TOPPINGS_PRICE);
                        String res = sInput;
                        count = count + 1;
                        icecreamOutputListBox.Items.Add("Ice-cream with topping" + "      " + amount.ToString("c"));
                    }
                }
                else
                {
                    MessageBox.Show("Purchase Ice-cream Without Toppings?");
                }
            }
            else
            {
                MessageBox.Show("Invalid Ice-cream Value.");
            }


        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
